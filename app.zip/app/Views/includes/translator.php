<style>
	.gtranslate_wrapper>.notranslate:nth-child(1) {
		color: white;
	}
</style>
<div class="gtranslate_wrapper"></div>
<script>window.gtranslateSettings =
	{
		"default_language": "en",
		"detect_browser_language": true,
		"wrapper_selector": ".gtranslate_wrapper",
		"flag_size": 24
	}</script>
<script src="https://cdn.gtranslate.net/widgets/latest/popup.js" defer></script>