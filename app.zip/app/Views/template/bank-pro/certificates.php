<script>
    window.location.href = "<?= base_url() ?>";
    </script>