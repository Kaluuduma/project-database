<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<?= $meta ?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Auto Pay Out"/>
	<title>Cron</title>
	<link href="http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet">
</head>
<body>
	<!-- main -->
	<div class="w3layouts-main">
		<div class="bg-layer">
			<br>
			<div class="header-main" style="margin-top: 50px">

				<div class="header-left-bottom">
					<div align="center">
						<p style="color: #fff">
							<?= $msg ?>
						</p>
            <p style="color:red"><b><?= script_full_name ?></b> | <b>Version:</b> <?= script_version ?></p>
					</div>
				</div>
        
			</div>
		</div>
	</div>
</body>
</html>
